package models

type Agent struct {
	Email   string
	Issues  []Issue
	AgentId int
	Free    bool
}

type Issue struct {
	Description   string
	IssueType     string
	TransactionId string
	IssueID       int
	Status        string
}

type IssueRequest struct {
	Email string
}
