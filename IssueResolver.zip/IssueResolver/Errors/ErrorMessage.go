package errorMessage

// var Error map[string]string{""}
// Error := map[string]string{
// "",""
// }
func GetError(errorType string) string {
	var Error map[string]string = make(map[string]string)
	Error["CreateIssue"] = "transactionId , issueType , and description is mandatory for creating an issue"
	Error["IssueNotFound"] = "IssueNotFound"
	Error["IssueAlreadyExists"] = "IssueAlreadyExists"
	Error["AgentNotFound"] = "AgentNotFound"
	Error["AgentAlreadyExists"] = "AgentAlreadyExists"
	Error["InvalidAgentRequest"] = "InvalidAgentRequest"
	Error["InvalidIssueType"] = "InvalidIssueType"
	Error["AllAgentBusy"] = "AllAgentBusy"
	Error["NoIssueForEmail"] = "NoIssueForEmail"
	return Error[errorType]

}
