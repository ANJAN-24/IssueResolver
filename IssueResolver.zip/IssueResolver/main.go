package main

import (
	agent "main.go/AgentWorkflow"
	issue "main.go/IssuesWorkflow"
)

// createIssue(transactionId, issueType, subject, description, email)
// addAgent(agentEmail, agentName ,List<issueType>)
// assignIssue(issueId) // -> Issue can be assigned to the agents based on different strategies. For now, assign to any one of the free agents.
// getIssues(filter) // -> issues against the provided filter
// updateIssue(issueId, status, resolution)
// resolveIssue(issueId, resolution)
// viewAgentsWorkHistory() // -> a list of issue which agents worked on
func main() {
	issue.CreateIssue("1", "issueType", "subject", "description", "email")
	issue.CreateIssue("2", "issueType", "subject", "description", "email")
	issueTypes := []string{"1", "2"}
	agent.AddAgent("gent1@test.com", "Agent 1", issueTypes)
	// issueTypes2 := []string{"", ""}
	// agent.AddAgent("gent2@test.com", "Agent 2", issueTypes2)
	issue.AssignIssue("1")
	issue.UpdateIssue("1", "In Progress", "Waiting for payment confirmation")
	// issue.AssignIssue("I2")
}
