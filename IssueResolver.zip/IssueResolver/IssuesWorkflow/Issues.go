package issue

import (
	"fmt"
	"strconv"

	data "main.go/DataStore"
	errorMessage "main.go/Errors"
	"main.go/models"
)

// IssueTypes := []string {"",""}

func CreateIssue(transactionId string, issueType string, subject string, description string, email string) {
	var issue models.Issue = models.Issue{TransactionId: transactionId, Description: description, IssueType: issueType}
	//validations
	if len(issue.Description) == 0 || len(issue.TransactionId) == 0 || len(issue.IssueType) == 0 {
		fmt.Println(errorMessage.GetError("CreateIssue"))
		return
	}
	v, err := data.SetData(issue)
	if len(err) != 0 {
		fmt.Println("Error : " + err)
		return
	}
	fmt.Println("Issue" + strconv.Itoa(v.IssueID) + " created against transaction " + transactionId)
}

func AssignIssue(id string) {
	// v, _ := strconv.Atoi(id)
	agent := data.GetAgentForIssue(id)
	if len(agent.Email) == 0 {
		fmt.Println(errorMessage.GetError("AllAgentBusy"))
		return
	}
	fmt.Println("Issue " + id + " added to waitlist of Agent" + agent.Email)
}

func GetIssue(body models.IssueRequest) {
	v := data.GetIssueOnEmail(body.Email)
	if len(v) == 0 {
		fmt.Println(errorMessage.GetError("NoIssueForEmail"))
		return
	}
	fmt.Println(v)

}

func UpdateIssue(Tid string, status string, description string) {
	// vaidations

	var issue models.Issue = models.Issue{Description: description, TransactionId: Tid, Status: status}
	data.UpdateIssue(issue)
}
