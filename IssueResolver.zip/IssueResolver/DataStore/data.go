package data

import (
	"fmt"
	"sync"

	errorMessage "main.go/Errors"
	"main.go/models"
)

var Issue map[string]models.Issue = make(map[string]models.Issue)
var Agent map[string]models.Agent = make(map[string]models.Agent)
var IssueID int
var AgentID int
var mutex sync.Mutex

func GetData(key string) (models.Issue, string) {
	mutex.Lock()
	defer mutex.Unlock()
	v, ok := Issue[key]
	if ok {
		return v, ""
	}
	return models.Issue{}, errorMessage.GetError("IssueNotFound")
}

func SetData(issue models.Issue) (models.Issue, string) {
	mutex.Lock()
	defer mutex.Unlock()
	v, ok := Issue[issue.TransactionId]
	if ok {
		return v, errorMessage.GetError("IssueAlreadyExists")
	}
	issue.IssueID = IssueID + 1
	Issue[issue.TransactionId] = issue
	return issue, ""
}

func SetIssueData(issue models.Issue) (models.Issue, string) {
	mutex.Lock()
	defer mutex.Unlock()
	v, ok := Issue[issue.TransactionId]
	if !ok {
		return v, errorMessage.GetError("IssueNotFound")
	}
	// issue.IssueID = IssueID + 1
	Issue[issue.TransactionId] = issue
	return issue, ""
}

func GetAgent(key string) (models.Agent, string) {
	mutex.Lock()
	defer mutex.Unlock()
	v, ok := Agent[key]
	if ok {
		return v, ""
	}
	return models.Agent{}, errorMessage.GetError("AgentNotFound")
}

func SetAgent(agent models.Agent) (models.Agent, string) {
	mutex.Lock()
	defer mutex.Unlock()
	v, ok := Agent[agent.Email]
	if ok {
		return v, errorMessage.GetError("AgentAlreadyExists")
	}
	agent.AgentId = AgentID + 1
	agent.Free = true
	Agent[agent.Email] = agent
	return agent, ""
}

func GetAllAgent() map[string]models.Agent {
	return Agent
}

func GetAgentForIssue(issue string) models.Agent {
	for _, v := range Agent {
		for i := range v.Issues {
			if v.Issues[i].IssueType == issue && v.Free {
				v.Free = false
				return v
			}
		}
	}
	return models.Agent{}

}

func GetIssueOnEmail(email string) []models.Issue {
	var issues []models.Issue
	for _, v := range Agent {
		if v.Email == email {
			issues = append(issues, v.Issues...)
		}
	}
	return issues
}

func UpdateIssue(issue models.Issue) {
	v, err := GetData(issue.TransactionId)
	if len(err) > 0 {
		fmt.Println(err)
		return
	}
	v.Description = issue.Description
	v.IssueID = issue.IssueID
	v.IssueType = issue.IssueType
	v, err1 := SetIssueData(v)
	if len(err1) != 0 {
		fmt.Println("something went wrong")
		return
	}
	fmt.Println("issue Updated" + issue.TransactionId)
}
