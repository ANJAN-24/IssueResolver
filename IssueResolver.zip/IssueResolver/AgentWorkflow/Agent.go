package agent

import (
	"fmt"
	"strconv"

	data "main.go/DataStore"
	errorMessage "main.go/Errors"
	"main.go/models"
)

func AddAgent(email string, Agent string, issues []string) {

	//validations
	if len(email) == 0 || len(issues) == 0 {
		fmt.Println(errorMessage.GetError("InvalidAentRequest"))
		return
	}

	var IssueTypes []models.Issue
	for i := range issues {
		if len(issues[i]) == 0 {
			errorMessage.GetError("InvalidIssueType")
			return
		}
		issue := models.Issue{IssueType: issues[i]}
		IssueTypes = append(IssueTypes, issue)
	}

	var agent models.Agent = models.Agent{Email: email, Issues: IssueTypes}
	v, err := data.SetAgent(agent)
	if len(err) != 0 {
		fmt.Println(err)
		return
	}
	fmt.Println("Agent " + strconv.Itoa(v.AgentId) + "created")
}
